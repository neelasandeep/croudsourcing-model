
<!DOCTYPE html>
<html>
<head>
	<title>del</title>
</head>
<body>
<?php
$db=mysqli_connect("localhost","root","","smindia");
session_start();
$tabl=$_SESSION['tname'];

$id=$_GET['sno'];
echo $id;
$del="DELETE FROM `$tabl` WHERE SNO='$id'";
$del=mysqli_query($db,$del);
if(!$del){
	echo "not deleted";
}else{
	echo "deleted";
}
header("location:qsearch1.php");

?>
</body>
</html>