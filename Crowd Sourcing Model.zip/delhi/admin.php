 

 <html>
    <head>
      <title> ADMIN </title>
      <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body >

      <header>
            <nav>
                <ul>
                <li><a class="homered" href="index.php"><img src="home1.jpg" style="width: 30px; height: 25px; align-self: left ;
    padding: 0px 20px 5px 0px;"></a></li>
            </ul>
                <h1>ADMIN PANEL</h1>
                <ul id="nav">
                    
                    <li><a class="homeblack" href="qsearch.php">Questions</a></li>
                    
                    <li><a class="homeblack" href="search.php">Search</a></li>
                    <li><a class="homeblack" href="stakelist.php">Stakeholders</a></li>
                </ul>       
            </nav>
        </header>
        <div class="divider"></div>

       <div class="fwimage">
           <h2 class="homesubline">WELCOME TO <span style="color: white;">CROWD SOURCING </span> WORLD</h2>
           <h1 class="homewhe">WHERE PEOPLE</h1>
           <h1 class="homepeo">GATHER</h1>
           <br>
          
       </div>


    </body>
</html>